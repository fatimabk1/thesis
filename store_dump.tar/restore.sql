--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE store;
--
-- Name: store; Type: DATABASE; Schema: -; Owner: fatimakahbi
--

CREATE DATABASE store WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE store OWNER TO fatimakahbi;

\connect store

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: category; Type: TABLE; Schema: public; Owner: fatimakahbi
--

CREATE TABLE public.category (
    cat_id integer NOT NULL,
    category character varying(50),
    coefficient real
);


ALTER TABLE public.category OWNER TO fatimakahbi;

--
-- Name: cost; Type: TABLE; Schema: public; Owner: fatimakahbi
--

CREATE TABLE public.cost (
    cost_id integer NOT NULL,
    stamp timestamp without time zone,
    value real,
    ctype character varying(30)
);


ALTER TABLE public.cost OWNER TO fatimakahbi;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: fatimakahbi
--

CREATE TABLE public.employee (
    emp_id integer NOT NULL,
    role_id integer
);


ALTER TABLE public.employee OWNER TO fatimakahbi;

--
-- Name: inventory; Type: TABLE; Schema: public; Owner: fatimakahbi
--

CREATE TABLE public.inventory (
    grp_id integer NOT NULL,
    shelved_stock integer,
    back_stock integer,
    cart_stock integer,
    exp_date timestamp without time zone NOT NULL
);


ALTER TABLE public.inventory OWNER TO fatimakahbi;

--
-- Name: price; Type: TABLE; Schema: public; Owner: fatimakahbi
--

CREATE TABLE public.price (
    grp_id integer NOT NULL,
    price real,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    qty_max integer
);


ALTER TABLE public.price OWNER TO fatimakahbi;

--
-- Name: product; Type: TABLE; Schema: public; Owner: fatimakahbi
--

CREATE TABLE public.product (
    grp_id integer NOT NULL,
    brand character varying(200),
    name character varying(600),
    lot_price real,
    lot_size integer,
    category integer
);


ALTER TABLE public.product OWNER TO fatimakahbi;

--
-- Name: revenue; Type: TABLE; Schema: public; Owner: fatimakahbi
--

CREATE TABLE public.revenue (
    rev_id integer NOT NULL,
    stamp timestamp without time zone,
    value real
);


ALTER TABLE public.revenue OWNER TO fatimakahbi;

--
-- Name: role; Type: TABLE; Schema: public; Owner: fatimakahbi
--

CREATE TABLE public.role (
    role_id integer NOT NULL,
    role character varying(100),
    hr_salary real,
    max_hrs integer
);


ALTER TABLE public.role OWNER TO fatimakahbi;

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: fatimakahbi
--

COPY public.category (cat_id, category, coefficient) FROM stdin;
\.
COPY public.category (cat_id, category, coefficient) FROM '$$PATH$$/3209.dat';

--
-- Data for Name: cost; Type: TABLE DATA; Schema: public; Owner: fatimakahbi
--

COPY public.cost (cost_id, stamp, value, ctype) FROM stdin;
\.
COPY public.cost (cost_id, stamp, value, ctype) FROM '$$PATH$$/3212.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: fatimakahbi
--

COPY public.employee (emp_id, role_id) FROM stdin;
\.
COPY public.employee (emp_id, role_id) FROM '$$PATH$$/3213.dat';

--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: fatimakahbi
--

COPY public.inventory (grp_id, shelved_stock, back_stock, cart_stock, exp_date) FROM stdin;
\.
COPY public.inventory (grp_id, shelved_stock, back_stock, cart_stock, exp_date) FROM '$$PATH$$/3207.dat';

--
-- Data for Name: price; Type: TABLE DATA; Schema: public; Owner: fatimakahbi
--

COPY public.price (grp_id, price, start_date, end_date, qty_max) FROM stdin;
\.
COPY public.price (grp_id, price, start_date, end_date, qty_max) FROM '$$PATH$$/3210.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: fatimakahbi
--

COPY public.product (grp_id, brand, name, lot_price, lot_size, category) FROM stdin;
\.
COPY public.product (grp_id, brand, name, lot_price, lot_size, category) FROM '$$PATH$$/3208.dat';

--
-- Data for Name: revenue; Type: TABLE DATA; Schema: public; Owner: fatimakahbi
--

COPY public.revenue (rev_id, stamp, value) FROM stdin;
\.
COPY public.revenue (rev_id, stamp, value) FROM '$$PATH$$/3211.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: fatimakahbi
--

COPY public.role (role_id, role, hr_salary, max_hrs) FROM stdin;
\.
COPY public.role (role_id, role, hr_salary, max_hrs) FROM '$$PATH$$/3214.dat';

--
-- Name: category pk_cat; Type: CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT pk_cat PRIMARY KEY (cat_id);


--
-- Name: cost pk_cost; Type: CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.cost
    ADD CONSTRAINT pk_cost PRIMARY KEY (cost_id);


--
-- Name: employee pk_emp; Type: CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT pk_emp PRIMARY KEY (emp_id);


--
-- Name: inventory pk_inv; Type: CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT pk_inv PRIMARY KEY (grp_id, exp_date);


--
-- Name: price pk_price; Type: CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT pk_price PRIMARY KEY (grp_id);


--
-- Name: product pk_prod; Type: CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT pk_prod PRIMARY KEY (grp_id);


--
-- Name: revenue pk_revenue; Type: CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.revenue
    ADD CONSTRAINT pk_revenue PRIMARY KEY (rev_id);


--
-- Name: role pk_role; Type: CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT pk_role PRIMARY KEY (role_id);


--
-- Name: inventory fk1_inv; Type: FK CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT fk1_inv FOREIGN KEY (grp_id) REFERENCES public.product(grp_id);


--
-- Name: price fk1_price; Type: FK CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT fk1_price FOREIGN KEY (grp_id) REFERENCES public.product(grp_id);


--
-- Name: inventory fk2_inv; Type: FK CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT fk2_inv FOREIGN KEY (grp_id) REFERENCES public.price(grp_id);


--
-- Name: product fk2_prod; Type: FK CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT fk2_prod FOREIGN KEY (grp_id) REFERENCES public.price(grp_id);


--
-- Name: product fk3_prod; Type: FK CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT fk3_prod FOREIGN KEY (category) REFERENCES public.category(cat_id);


--
-- Name: employee fk_emp; Type: FK CONSTRAINT; Schema: public; Owner: fatimakahbi
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT fk_emp FOREIGN KEY (role_id) REFERENCES public.role(role_id);


--
-- PostgreSQL database dump complete
--

